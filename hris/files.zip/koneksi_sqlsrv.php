<?php
/**
 * koneksi_sqlsrv.php — pengganti config/koneksi.php & connection.php (versi SQL Server)
 * Include file ini di aplikasi HRIS, lalu ubah semua pemanggilan mysqli_* / $mysqli->
 * menjadi fungsi sqlsrv_* atau helper di bawah.
 */
$serverName = "spsdmz2";
$connInfo = [
    "UID" => "sa",
    "PWD" => "supracor",
    "Database" => "hris",
    "CharacterSet" => "UTF-8",
    "TrustServerCertificate" => true,
];

$conn = sqlsrv_connect($serverName, $connInfo);
if ($conn === false) {
    die("Koneksi gagal: " . print_r(sqlsrv_errors(), true));
}

/* ===== Helper agar migrasi dari mysqli lebih mudah ===== */

// pengganti: $result = mysqli_query($conn, $sql)
function db_query($sql, $params = []) {
    global $conn;
    $stmt = sqlsrv_query($conn, $sql, $params, ["Scrollable" => SQLSRV_CURSOR_CLIENT_BUFFERED]);
    if ($stmt === false) {
        die("Query error: " . print_r(sqlsrv_errors(), true) . "\nSQL: " . $sql);
    }
    return $stmt;
}

// pengganti: mysqli_fetch_assoc($result)
function db_fetch_assoc($stmt) {
    return sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
}

// pengganti: mysqli_num_rows($result)
function db_num_rows($stmt) {
    return sqlsrv_num_rows($stmt);
}

// pengganti: mysqli_insert_id($conn)  → id terakhir (IDENTITY)
function db_insert_id() {
    global $conn;
    $s = sqlsrv_query($conn, "SELECT SCOPE_IDENTITY() AS id");
    $r = sqlsrv_fetch_array($s, SQLSRV_FETCH_ASSOC);
    return $r['id'] ?? null;
}

// pengganti: mysqli_real_escape_string — LEBIH BAIK pakai parameter (?), contoh:
//   db_query("SELECT * FROM pegawai WHERE id_peg = ?", [$id]);
function db_escape($str) {
    return str_replace("'", "''", $str);
}
