<?php
/**
 * import_db_sqlsrv.php
 * Import hris_sqlserver.sql ke SQL Server (spsdmz2) via ekstensi sqlsrv.
 * Letakkan file ini + hris_sqlserver.sql di C:\xampp\htdocs\
 * lalu buka: http://edp2:8081/import_db_sqlsrv.php
 */
set_time_limit(300);
header('Content-Type: text/plain; charset=utf-8');

// ====== KONFIGURASI (sesuaikan bila perlu) ======
$serverName = "spsdmz2";
$connInfo = [
    "UID" => "sa",
    "PWD" => "supracor",
    "Database" => "master",          // konek ke master dulu, script akan CREATE DATABASE hris
    "CharacterSet" => "UTF-8",
    "TrustServerCertificate" => true,
];
$sqlFile = __DIR__ . "/hris_sqlserver.sql";
// =================================================

echo "Memulai impor $sqlFile ke SQL Server ($serverName)...\n\n";

if (!file_exists($sqlFile)) {
    die("ERROR: File $sqlFile tidak ditemukan.\n");
}

$conn = sqlsrv_connect($serverName, $connInfo);
if ($conn === false) {
    die("Koneksi gagal:\n" . print_r(sqlsrv_errors(), true));
}
echo "Terkoneksi ke $serverName.\n\n";

// Split berdasarkan baris "GO" (batch separator, bukan bagian dari T-SQL)
$sql = file_get_contents($sqlFile);
$batches = preg_split('/^\s*GO\s*$/mi', $sql);

$ok = 0; $fail = 0;
foreach ($batches as $i => $batch) {
    $batch = trim($batch);
    if ($batch === '') continue;
    $stmt = sqlsrv_query($conn, $batch);
    if ($stmt === false) {
        $fail++;
        echo "== GAGAL pada batch #" . ($i + 1) . " ==\n";
        echo substr($batch, 0, 200) . "...\n";
        print_r(sqlsrv_errors());
        echo "\n";
    } else {
        $ok++;
        sqlsrv_free_stmt($stmt);
    }
}

echo "\nSelesai. Batch sukses: $ok, gagal: $fail\n";

// Verifikasi
$conn2 = sqlsrv_connect($serverName, array_merge($connInfo, ["Database" => "hris"]));
if ($conn2) {
    $r = sqlsrv_query($conn2, "SELECT name FROM sys.tables ORDER BY name");
    echo "\nTabel di database hris:\n";
    while ($row = sqlsrv_fetch_array($r, SQLSRV_FETCH_ASSOC)) {
        echo " - " . $row['name'] . "\n";
    }
}
