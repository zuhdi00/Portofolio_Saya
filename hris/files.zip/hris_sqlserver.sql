-- Converted from MySQL dump (hris) to SQL Server T-SQL
-- Target: spsdmz2  |  Generated automatically
IF DB_ID('hris') IS NULL CREATE DATABASE hris;
GO
USE hris;
GO
-- Drop existing tables (safe re-run)
IF OBJECT_ID(N'[dbo].[dokumen_pendukung]', 'U') IS NOT NULL DROP TABLE [dbo].[dokumen_pendukung];
IF OBJECT_ID(N'[dbo].[riwayat_perubahan_kontrak]', 'U') IS NOT NULL DROP TABLE [dbo].[riwayat_perubahan_kontrak];
IF OBJECT_ID(N'[dbo].[tahap_lamaran]', 'U') IS NOT NULL DROP TABLE [dbo].[tahap_lamaran];
IF OBJECT_ID(N'[dbo].[tabel_riwayat_cuti]', 'U') IS NOT NULL DROP TABLE [dbo].[tabel_riwayat_cuti];
IF OBJECT_ID(N'[dbo].[tabel cuti]', 'U') IS NOT NULL DROP TABLE [dbo].[tabel cuti];
IF OBJECT_ID(N'[dbo].[slip_gaji]', 'U') IS NOT NULL DROP TABLE [dbo].[slip_gaji];
IF OBJECT_ID(N'[dbo].[promosi]', 'U') IS NOT NULL DROP TABLE [dbo].[promosi];
IF OBJECT_ID(N'[dbo].[potongan_gaji]', 'U') IS NOT NULL DROP TABLE [dbo].[potongan_gaji];
IF OBJECT_ID(N'[dbo].[phk]', 'U') IS NOT NULL DROP TABLE [dbo].[phk];
IF OBJECT_ID(N'[dbo].[penilaian_pelamar]', 'U') IS NOT NULL DROP TABLE [dbo].[penilaian_pelamar];
IF OBJECT_ID(N'[dbo].[penilaian]', 'U') IS NOT NULL DROP TABLE [dbo].[penilaian];
IF OBJECT_ID(N'[dbo].[pengunduran_diri]', 'U') IS NOT NULL DROP TABLE [dbo].[pengunduran_diri];
IF OBJECT_ID(N'[dbo].[penghargaan]', 'U') IS NOT NULL DROP TABLE [dbo].[penghargaan];
IF OBJECT_ID(N'[dbo].[penggajian]', 'U') IS NOT NULL DROP TABLE [dbo].[penggajian];
IF OBJECT_ID(N'[dbo].[pelamar]', 'U') IS NOT NULL DROP TABLE [dbo].[pelamar];
IF OBJECT_ID(N'[dbo].[pegawai]', 'U') IS NOT NULL DROP TABLE [dbo].[pegawai];
IF OBJECT_ID(N'[dbo].[mutasi]', 'U') IS NOT NULL DROP TABLE [dbo].[mutasi];
IF OBJECT_ID(N'[dbo].[lowongan]', 'U') IS NOT NULL DROP TABLE [dbo].[lowongan];
IF OBJECT_ID(N'[dbo].[laporan_sdm]', 'U') IS NOT NULL DROP TABLE [dbo].[laporan_sdm];
IF OBJECT_ID(N'[dbo].[kpi]', 'U') IS NOT NULL DROP TABLE [dbo].[kpi];
IF OBJECT_ID(N'[dbo].[kontrak_pegawai]', 'U') IS NOT NULL DROP TABLE [dbo].[kontrak_pegawai];
IF OBJECT_ID(N'[dbo].[keterlambatan dan ketidakhadiran]', 'U') IS NOT NULL DROP TABLE [dbo].[keterlambatan dan ketidakhadiran];
IF OBJECT_ID(N'[dbo].[kedisiplinan]', 'U') IS NOT NULL DROP TABLE [dbo].[kedisiplinan];
IF OBJECT_ID(N'[dbo].[jenis_cuti]', 'U') IS NOT NULL DROP TABLE [dbo].[jenis_cuti];
IF OBJECT_ID(N'[dbo].[jadwal_kehadiran]', 'U') IS NOT NULL DROP TABLE [dbo].[jadwal_kehadiran];
IF OBJECT_ID(N'[dbo].[jabatan]', 'U') IS NOT NULL DROP TABLE [dbo].[jabatan];
IF OBJECT_ID(N'[dbo].[departemen]', 'U') IS NOT NULL DROP TABLE [dbo].[departemen];
IF OBJECT_ID(N'[dbo].[analisis_sdm]', 'U') IS NOT NULL DROP TABLE [dbo].[analisis_sdm];
IF OBJECT_ID(N'[dbo].[absensi]', 'U') IS NOT NULL DROP TABLE [dbo].[absensi];
GO
CREATE TABLE [dbo].[absensi] (
    [ID_Absensi] INT NOT NULL,
    [ID_Pegawai] INT NOT NULL,
    [Tanggal_Waktu] DATETIME NOT NULL,
    [Status_Kehadiran] NVARCHAR(10) NOT NULL,
    [Metode_Verifikasi] NVARCHAR(20) NOT NULL,
    [Lokasi_IP] NVARCHAR(45) DEFAULT NULL,
    CONSTRAINT [PK_absensi] PRIMARY KEY ([ID_Absensi])
);
GO
CREATE TABLE [dbo].[analisis_sdm] (
    [id_analisis] INT NOT NULL,
    [judul_analisis] NVARCHAR(255) NOT NULL,
    [deskripsi] NVARCHAR(MAX) NOT NULL,
    [tanggal_analisis] DATE NOT NULL,
    [jenis_analisis] NVARCHAR(20) NOT NULL,
    CONSTRAINT [PK_analisis_sdm] PRIMARY KEY ([id_analisis]),
    CONSTRAINT [CK_analisis_sdm_jenis_analisis] CHECK ([jenis_analisis] = N'Kehadiran' OR [jenis_analisis] = N'Kinerja' OR [jenis_analisis] = N'Pelatihan' OR [jenis_analisis] = N'Penghargaan')
);
GO
CREATE TABLE [dbo].[departemen] (
    [id_departemen] INT NOT NULL,
    [nama_departemen] NVARCHAR(100) NOT NULL,
    [kepala_departemen] NVARCHAR(100) NOT NULL,
    [lokasi_departemen] NVARCHAR(255) NOT NULL,
    CONSTRAINT [PK_departemen] PRIMARY KEY ([id_departemen])
);
GO
CREATE TABLE [dbo].[dokumen_pendukung] (
    [id] INT IDENTITY(3,1) NOT NULL,
    [kontrak_id] INT NOT NULL,
    [nama_dokumen] NVARCHAR(255) NOT NULL,
    [file_path] NVARCHAR(255) NOT NULL,
    [tanggal_upload] DATETIME DEFAULT GETDATE(),
    [keterangan] NVARCHAR(MAX),
    CONSTRAINT [PK_dokumen_pendukung] PRIMARY KEY ([id])
);
CREATE INDEX [IX_dokumen_pendukung_kontrak_id] ON [dbo].[dokumen_pendukung] ([kontrak_id]);
GO
CREATE TABLE [dbo].[jabatan] (
    [id_jabatan] INT NOT NULL,
    [nama_jabatan] NVARCHAR(100) NOT NULL,
    [desk_jabatan] NVARCHAR(MAX) NOT NULL,
    [level_jabatan] TINYINT NOT NULL,
    [status_jabatan] NVARCHAR(20) NOT NULL,
    [id_departemen] INT NOT NULL,
    CONSTRAINT [PK_jabatan] PRIMARY KEY ([id_jabatan]),
    CONSTRAINT [UQ_jabatan_id_departemen] UNIQUE ([id_departemen]),
    CONSTRAINT [CK_jabatan_status_jabatan] CHECK ([status_jabatan] = N'Tersedia' OR [status_jabatan] = N'Tidak Tersedia')
);
GO
CREATE TABLE [dbo].[jadwal_kehadiran] (
    [ID_Jadwal] INT NOT NULL,
    [ID_Pegawai] INT NOT NULL,
    [Hari] NVARCHAR(10) NOT NULL,
    [Jam_Masuk] TIME(0) NOT NULL,
    [Jam_Keluar] TIME(0) NOT NULL,
    [Keterangan] NVARCHAR(MAX),
    CONSTRAINT [PK_jadwal_kehadiran] PRIMARY KEY ([ID_Jadwal])
);
GO
CREATE TABLE [dbo].[jenis_cuti] (
    [id_jenis_cuti] INT NOT NULL,
    [nama_jenis_cuti] NVARCHAR(100) NOT NULL,
    [keterangan] NVARCHAR(MAX) NOT NULL,
    CONSTRAINT [PK_jenis_cuti] PRIMARY KEY ([id_jenis_cuti])
);
GO
CREATE TABLE [dbo].[kedisiplinan] (
    [id_kedisiplinan] INT IDENTITY(4,1) NOT NULL,
    [sanksi] NVARCHAR(255) NOT NULL,
    [jenis_pelanggaran] NVARCHAR(255) NOT NULL,
    [id_peg] INT NOT NULL,
    CONSTRAINT [PK_kedisiplinan] PRIMARY KEY ([id_kedisiplinan])
);
GO
CREATE TABLE [dbo].[keterlambatan dan ketidakhadiran] (
    [ID_ketidakhadiran] INT NOT NULL,
    [Tanggal] DATE NOT NULL,
    [Jam_Masuk_Terlambat] TIME(0) NOT NULL,
    [Alasan_Keterlambatan] NVARCHAR(MAX) NOT NULL
);
GO
CREATE TABLE [dbo].[kontrak_pegawai] (
    [id] INT IDENTITY(3,1) NOT NULL,
    [pegawai_id] INT NOT NULL,
    [nomor_kontrak] NVARCHAR(50) NOT NULL,
    [tanggal_mulai] DATE NOT NULL,
    [tanggal_berakhir] DATE NOT NULL,
    [jabatan] NVARCHAR(100) NOT NULL,
    [gaji] DECIMAL(15,2) NOT NULL,
    [status_kontrak] NVARCHAR(20) DEFAULT N'Aktif',
    [created_at] DATETIME DEFAULT GETDATE(),
    [updated_at] DATETIME DEFAULT GETDATE(),
    CONSTRAINT [PK_kontrak_pegawai] PRIMARY KEY ([id]),
    CONSTRAINT [CK_kontrak_pegawai_status_kontrak] CHECK ([status_kontrak] = N'Aktif' OR [status_kontrak] = N'Non-Aktif')
);
GO
CREATE TABLE [dbo].[kpi] (
    [id_kpi] INT NOT NULL,
    [deskripsi] NVARCHAR(MAX) NOT NULL,
    [target] NVARCHAR(128) NOT NULL,
    [bobot] NVARCHAR(128) NOT NULL,
    [id_peg] INT NOT NULL,
    CONSTRAINT [PK_kpi] PRIMARY KEY ([id_kpi]),
    CONSTRAINT [UQ_kpi_id_peg] UNIQUE ([id_peg])
);
GO
CREATE TABLE [dbo].[laporan_sdm] (
    [id_laporan] INT NOT NULL,
    [judul_laporan] NVARCHAR(255) NOT NULL,
    [periode_awal] DATE NOT NULL,
    [periode_akhir] DATE NOT NULL,
    [isi_laporan] NVARCHAR(MAX) NOT NULL,
    [tanggal_dibuat] DATE NOT NULL,
    CONSTRAINT [PK_laporan_sdm] PRIMARY KEY ([id_laporan])
);
GO
CREATE TABLE [dbo].[lowongan] (
    [id_lowongan] INT NOT NULL,
    [nama_lowongan] NVARCHAR(128) NOT NULL,
    [deskripsi_lowongan] NVARCHAR(MAX) NOT NULL,
    [id_jabatan] INT NOT NULL,
    [tgl_posting] DATE NOT NULL,
    [tgl_tutup] DATE NOT NULL,
    [status] NVARCHAR(20) NOT NULL,
    CONSTRAINT [PK_lowongan] PRIMARY KEY ([id_lowongan]),
    CONSTRAINT [UQ_lowongan_id_jabatan] UNIQUE ([id_jabatan]),
    CONSTRAINT [CK_lowongan_status] CHECK ([status] = N'Tersedia' OR [status] = N'Tidak Tersedia')
);
GO
CREATE TABLE [dbo].[mutasi] (
    [id_mutasi] INT NOT NULL,
    [id_pegawai] INT NOT NULL,
    [dep_lama] NVARCHAR(50) NOT NULL,
    [dep_baru] NVARCHAR(50) NOT NULL,
    [tgl_mutasi] DATE NOT NULL,
    [alasan_mutasi] NVARCHAR(MAX) NOT NULL
);
GO
CREATE TABLE [dbo].[pegawai] (
    [id_peg] INT IDENTITY(1,1) NOT NULL,
    [nama_pegawai] NVARCHAR(255) NOT NULL,
    [jabatan] NVARCHAR(255) NOT NULL,
    [departemen] NVARCHAR(255) NOT NULL,
    CONSTRAINT [PK_pegawai] PRIMARY KEY ([id_peg])
);
GO
CREATE TABLE [dbo].[pelamar] (
    [id_pelamar] INT NOT NULL,
    [nama_pel] NVARCHAR(128) NOT NULL,
    [email_pel] NVARCHAR(128) NOT NULL,
    [id_lowongan] INT NOT NULL,
    [status_pel] NVARCHAR(20) NOT NULL,
    [jabatan_dipilih] NVARCHAR(100) NOT NULL,
    CONSTRAINT [CK_pelamar_status_pel] CHECK ([status_pel] = N'Diterima' OR [status_pel] = N'Ditolak')
);
GO
CREATE TABLE [dbo].[penggajian] (
    [id_jabatan] INT NOT NULL,
    [nama_jabatan] NVARCHAR(120) NOT NULL,
    [id_penggajian] INT NOT NULL,
    [gaji_pokok] NVARCHAR(50) NOT NULL,
    [id_tunjangan] INT NOT NULL,
    [tj_transportasi] NVARCHAR(50) NOT NULL,
    [tj_kesehatan] NVARCHAR(50) NOT NULL,
    [bonus] DECIMAL(38,0) NOT NULL
);
GO
CREATE TABLE [dbo].[penghargaan] (
    [id_peng] INT NOT NULL,
    [nama_peng] NVARCHAR(128) NOT NULL,
    [jenis_peng] NVARCHAR(128) NOT NULL,
    [desk_peng] NVARCHAR(MAX) NOT NULL,
    [id_peg] INT NOT NULL
);
GO
CREATE TABLE [dbo].[pengunduran_diri] (
    [id_pengunduran] INT NOT NULL,
    [id_karyawan] INT NOT NULL,
    [tanggal_pengajuan] DATE NOT NULL,
    [tanggal_efektif] DATE NOT NULL,
    [alasan] NVARCHAR(MAX) NOT NULL,
    [status_pengajuan] NVARCHAR(20) NOT NULL,
    CONSTRAINT [CK_pengunduran_diri_status_pengajuan] CHECK ([status_pengajuan] = N'Menunggu' OR [status_pengajuan] = N'Disetujui' OR [status_pengajuan] = N'Ditolak' OR [status_pengajuan] = N'')
);
GO
CREATE TABLE [dbo].[penilaian] (
    [id_penilaian] INT NOT NULL,
    [id_pegawai] INT NOT NULL,
    [id_KPI] INT NOT NULL,
    [nilai] INT NOT NULL,
    [periode penilaian] DATE NOT NULL
);
GO
CREATE TABLE [dbo].[penilaian_pelamar] (
    [id_penilaian_pel] INT NOT NULL,
    [id_pelamar] INT NOT NULL,
    [id_tahap] INT NOT NULL,
    [tgl_dinilai] DATE NOT NULL,
    [skor] INT NOT NULL,
    [catatan] NVARCHAR(MAX) NOT NULL
);
GO
CREATE TABLE [dbo].[phk] (
    [id_phk] INT NOT NULL,
    [id_karyawan] INT NOT NULL,
    [tanggal_phk] DATE NOT NULL,
    [alasan_phk] NVARCHAR(MAX) NOT NULL,
    [status_kompensasi] NVARCHAR(20) NOT NULL,
    [jumlah_kompensasi] DECIMAL(10,0) NOT NULL,
    CONSTRAINT [CK_phk_status_kompensasi] CHECK ([status_kompensasi] = N'Diberikan' OR [status_kompensasi] = N'Tidak Diberikan' OR [status_kompensasi] = N'')
);
GO
CREATE TABLE [dbo].[potongan_gaji] (
    [id] INT NOT NULL,
    [potongan] NVARCHAR(120) NOT NULL,
    [jml_potongan] INT NOT NULL
);
GO
CREATE TABLE [dbo].[promosi] (
    [id_promosi] INT NOT NULL,
    [id_peg] INT NOT NULL,
    [jab_lama] NVARCHAR(50) NOT NULL,
    [jab_baru] NVARCHAR(50) NOT NULL,
    [tgl_promosi] DATE NOT NULL,
    [alasan_promosi] NVARCHAR(MAX) NOT NULL
);
GO
CREATE TABLE [dbo].[riwayat_perubahan_kontrak] (
    [id] INT IDENTITY(5,1) NOT NULL,
    [kontrak_id] INT NOT NULL,
    [perubahan] NVARCHAR(MAX) NOT NULL,
    [tanggal_perubahan] DATETIME DEFAULT GETDATE(),
    [dibuat_oleh] NVARCHAR(100) NOT NULL,
    [gaji_sebelum_perubahan] NVARCHAR(255) NOT NULL,
    [gaji_setelah_perubahan] NVARCHAR(255) NOT NULL,
    CONSTRAINT [PK_riwayat_perubahan_kontrak] PRIMARY KEY ([id])
);
CREATE INDEX [IX_riwayat_perubahan_kontrak_kontrak_id] ON [dbo].[riwayat_perubahan_kontrak] ([kontrak_id]);
GO
CREATE TABLE [dbo].[slip_gaji] (
    [id_slip_gaji] INT NOT NULL,
    [bulan_tahun] DATE NOT NULL,
    [gaji_pokok] DECIMAL(30,0) NOT NULL,
    [tunjangan] DECIMAL(30,0) NOT NULL,
    [potongan] DECIMAL(30,0) NOT NULL,
    [total_gaji] DECIMAL(30,0) NOT NULL,
    [id_peg] INT NOT NULL
);
GO
CREATE TABLE [dbo].[tabel cuti] (
    [id_cuti] INT NOT NULL,
    [id_karyawan] INT NOT NULL,
    [id_jenis_cuti] INT NOT NULL,
    [tanggal_mulai] DATE NOT NULL,
    [tanggal_selesai] DATE NOT NULL,
    [status_cuti] NVARCHAR(100) NOT NULL,
    [tanggal_pengajuan] DATE NOT NULL
);
GO
CREATE TABLE [dbo].[tabel_riwayat_cuti] (
    [id_riwayat_cuti] INT NOT NULL,
    [id_karyawan] INT NOT NULL,
    [id_jenis_cuti] INT NOT NULL,
    [tanggal_mulai] DATE NOT NULL,
    [tanggal_selesai] DATE NOT NULL,
    [jumlah_hari] INT NOT NULL,
    [status_cuti] NVARCHAR(20) NOT NULL,
    CONSTRAINT [CK_tabel_riwayat_cuti_status_cuti] CHECK ([status_cuti] = N'Diterima' OR [status_cuti] = N'Selesai' OR [status_cuti] = N'Kadaluarsa')
);
GO
CREATE TABLE [dbo].[tahap_lamaran] (
    [id_tahap] INT NOT NULL,
    [nama_tahap] NVARCHAR(128) NOT NULL,
    [deskripsi_tahap] NVARCHAR(MAX) NOT NULL
);
GO
-- Data
INSERT INTO [dbo].[departemen] ([id_departemen], [nama_departemen], [kepala_departemen], [lokasi_departemen]) VALUES
(1, N'Sumber Daya Manusia', N'Diana Putri', N'Lantai 3, Gedung A');
GO
SET IDENTITY_INSERT [dbo].[kedisiplinan] ON;
INSERT INTO [dbo].[kedisiplinan] ([id_kedisiplinan], [sanksi], [jenis_pelanggaran], [id_peg]) VALUES
(1, N'denda', N'cabul', 2123034),
(2, N'skors 1 hari', N'telat', 2123035),
(3, N'denda', N'makan di kelas', 212121);
SET IDENTITY_INSERT [dbo].[kedisiplinan] OFF;
GO
SET IDENTITY_INSERT [dbo].[kontrak_pegawai] ON;
INSERT INTO [dbo].[kontrak_pegawai] ([id], [pegawai_id], [nomor_kontrak], [tanggal_mulai], [tanggal_berakhir], [jabatan], [gaji], [status_kontrak], [created_at], [updated_at]) VALUES
(1, 111111, N'21', N'2222-02-12', N'2222-02-22', N'direktur', N'10000000.00', N'Aktif', N'2025-02-03 19:16:35', N'2025-02-03 19:16:35'),
(2, 2123026, N'99', N'2025-02-03', N'0026-01-31', N'direktur utama', N'10000000.00', N'Aktif', N'2025-02-03 19:33:08', N'2025-02-03 19:33:08');
SET IDENTITY_INSERT [dbo].[kontrak_pegawai] OFF;
GO
-- Foreign keys
ALTER TABLE [dbo].[dokumen_pendukung] ADD CONSTRAINT [dokumen_pendukung_ibfk_1] FOREIGN KEY ([kontrak_id]) REFERENCES [dbo].[kontrak_pegawai] ([id]);
ALTER TABLE [dbo].[riwayat_perubahan_kontrak] ADD CONSTRAINT [riwayat_perubahan_kontrak_ibfk_1] FOREIGN KEY ([kontrak_id]) REFERENCES [dbo].[kontrak_pegawai] ([id]);
GO
