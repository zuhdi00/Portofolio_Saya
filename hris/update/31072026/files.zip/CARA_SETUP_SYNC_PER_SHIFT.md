# Setup Sync Otomatis Tiap Pergantian Shift

Sync jalan 3x sehari di pergantian shift, tiap kali tarik data hari ini
(mundur 1 hari untuk menjaring shift malam yang lintas tengah malam).

## Jadwal

| Waktu   | Menangkap                                    |
|---------|----------------------------------------------|
| 08:00   | seluruh shift 3 (malam, 00:00-08:00) + awal shift 1 |
| 16:00   | seluruh shift 1 (pagi, 08:00-16:00)          |
| 00:00   | seluruh shift 2 (sore, 16:00-00:00)          |

Waktu boleh digeser +15 menit (mis. 08:15, 16:15, 00:15) supaya semua
tap di akhir shift sudah masuk mesin sebelum ditarik.

## File yang dijalankan

Satu file gabungan menjalankan salin + impor + proses:

    C:\xampp\htdocs\hris\presensi\sync_lengkap_zkteco.bat

## Cara buat di Task Scheduler

1. Task Scheduler -> Create Task
2. Tab General:
   - Name: ZKTeco Sync Shift
   - "Run only when user is logged on" (paling mudah, tanpa password)
     ATAU "Run whether logged on or not" + akun ber-password (whoami)
   - Centang "Run with highest privileges"
3. Tab Triggers -> New (BUAT TIGA trigger, satu per waktu):

   Trigger 1: Daily, Start 08:15
   Trigger 2: Daily, Start 16:15
   Trigger 3: Daily, Start 00:15

   (Klik New tiga kali, satu jadwal tiap kali. Semua di satu task.)

4. Tab Actions -> New:
   - Start a program
   - Program: C:\xampp\htdocs\hris\presensi\sync_lengkap_zkteco.bat
5. Tab Conditions: hapus centang "Start only if on AC power"
6. Tab Settings:
   - Centang "Run task as soon as possible after a scheduled start is missed"
   - If already running: Do not start a new instance
7. OK

## Uji

Klik kanan task -> Run. Lalu:

    type C:\zkteco_data\sync.log

Cek data masuk:
    (SSMS)
    SELECT last_checktime, last_run, jml_baru, status FROM dbo.sync_zkteco_state;
    SELECT MAX(tanggal) FROM dbo.absensi;

## Catatan

- last_checktime sudah maju otomatis tiap sync, jadi tarikan berikutnya
  hanya ambil yang baru. Ringan (hitungan detik).
- Pengaman BATAS_MUNDUR_HARI=7 di import mencegah tarik masal kalau
  last_checktime tak sengaja ter-reset.
- Salin MDB (v4) menghapus salinan lama tiap jalan, jadi disk tidak menumpuk.
