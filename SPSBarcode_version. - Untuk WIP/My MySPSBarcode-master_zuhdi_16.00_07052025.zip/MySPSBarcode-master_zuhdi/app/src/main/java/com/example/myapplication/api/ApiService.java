package com.example.myapplication.api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Field;
import retrofit2.http.Query;

import com.example.myapplication.model.ServerResponse;
import com.example.myapplication.ItemDetailResponse;
import com.example.myapplication.model.TestResponses;

public interface ApiService {

    @GET("api_get_data.php")
    Call<ApiResponse> fetchData();

    @GET("api_get_item_detail.php")
    Call<ItemDetailResponse> getItemDetail(@Query("barcode") String barcode);

    @GET("test_connection.php")
    Call<TestResponses> testConnection();

    @FormUrlEncoded
    @POST("api_update_qty.php")
    Call<ServerResponse> updateQty(
            @Field("cNoOp") String cNoOp,
            @Field("nQty") double nQty
    );
    @FormUrlEncoded
    @POST("api_update_rak.php")
    Call<ServerResponse> updateRak(
            @Field("cNoOp") String cNoOp,
            @Field("cRak") String cRak
    );
}
