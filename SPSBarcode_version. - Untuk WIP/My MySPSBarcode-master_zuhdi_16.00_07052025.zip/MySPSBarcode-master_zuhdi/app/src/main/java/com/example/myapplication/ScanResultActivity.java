package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.ApiService;
import com.example.myapplication.model.ItemDetail;
import com.example.myapplication.model.ServerResponse;
import com.google.gson.Gson;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanResultActivity extends AppCompatActivity {
    private TextView resultTextView;
    private Button btnEdit;
    private ItemDetail detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_result);

        resultTextView = findViewById(R.id.resultTextView);
        btnEdit = findViewById(R.id.btnEdit);

        String scannedData = getIntent().getStringExtra("scanned_data");
        String detailJson = getIntent().getStringExtra("detail");

        if (detailJson != null) {
            Gson gson = new Gson();
            detail = gson.fromJson(detailJson, ItemDetail.class);
        }

        showDetail(scannedData);

        btnEdit.setOnClickListener(v -> showEditOptionsDialog());
    }

    private void showDetail(String scannedData) {
        StringBuilder resultBuilder = new StringBuilder();

        if (scannedData != null) {
            resultBuilder.append("Hasil Scan: ").append(scannedData).append("\n\n");
        }

        if (detail != null) {
            resultBuilder.append("Detail Barang:\n");
            resultBuilder.append("No STB       : ").append(detail.cNoSTB).append("\n");
            resultBuilder.append("Nama Barang  : ").append(detail.cNamabrg).append("\n");
            resultBuilder.append("No MC        : ").append(detail.cNoMC).append("\n");
            resultBuilder.append("No OP        : ").append(detail.cNoOp).append("\n");
            resultBuilder.append("Nama         : ").append(detail.cNama).append("\n");
            resultBuilder.append("Ukuran       : ")
                    .append(detail.nPanjang).append(" x ")
                    .append(detail.nLebar).append(" x ")
                    .append(detail.nTinggi).append("\n");
            resultBuilder.append("Warna        : ").append(detail.cWarna).append("\n");
            resultBuilder.append("Kualitas     : ")
                    .append(detail.cSub1).append(" / ")
                    .append(detail.cSub2).append(" / ")
                    .append(detail.cSub3).append(" / ")
                    .append(detail.cSub4).append(" / ")
                    .append(detail.cSub5).append("\n");
            resultBuilder.append("Jmlh Barang  : ").append(detail.nQty).append("\n");
            resultBuilder.append("Total KG     : ").append(detail.nQtyKg).append("\n");
            resultBuilder.append("Tgl Serah    : ").append(detail.dTglSerah).append("\n");
            resultBuilder.append("Rak          : ").append(detail.cRak).append("\n");
        } else {
            resultBuilder.append("Tidak ada detail barang ditemukan.");
        }

        resultTextView.setText(resultBuilder.toString());
    }

    private void showEditOptionsDialog() {
        String[] options = {"Edit Qty", "Edit Rak"};
        new AlertDialog.Builder(this)
                .setTitle("Pilih Atribut yang Diedit")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        showEditQtyDialog();
                    } else {
                        showEditRakDialog(); // Tambah fungsi untuk Edit Rak
                    }
                })
                .show();
    }

    private void showEditQtyDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_qty, null);
        final TextView qtyInput = dialogView.findViewById(R.id.editQtyInput);
        qtyInput.setText(String.valueOf(detail.nQty));

        new AlertDialog.Builder(this)
                .setTitle("Edit Qty")
                .setView(dialogView)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    try {
                        double newQty = Double.parseDouble(qtyInput.getText().toString());
                        updateQtyToServer(detail.cNoOp, newQty);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Qty tidak valid", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    // Fungsi untuk Edit Rak
    private void showEditRakDialog() {

        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_rak, null);
        final Spinner rakSpinner = dialogView.findViewById(R.id.spinnerRak);
        

        // Data rak untuk spinner
        String[] rakOptions = {"A-1", "A-2", "B-1", "B-2", "C-1", "C-2", "CORRUGATING 1", "CORRUGATING 2",
                "FOLDER GLUE", "FLADBAD", "FLEXO-1", "FLEXO-2", "FLEXO-4", "FLEXO-5", "FLEXO-6", "FLEXO-7",
                "FLEXO-8", "FLEXO-9", "IKAT", "LANTHEC", "LANGSUNG KIRIM", "RDC", "RAK-A", "RAK-B", "SLITTER", "STITCHING"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, rakOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rakSpinner.setAdapter(adapter);

        new AlertDialog.Builder(this)
                .setTitle("Edit Rak")
                .setView(dialogView)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String selectedRak = rakSpinner.getSelectedItem().toString();
                    updateRakToServer(detail.cNoOp, selectedRak); // Update rak ke server
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateQtyToServer(String cNoOp, double newQty) {
        ApiService service = ApiClient.getClient().create(ApiService.class);
        service.updateQty(cNoOp, newQty).enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    detail.nQty = newQty;
                    showDetail(null);
                    Toast.makeText(ScanResultActivity.this, "Qty berhasil diperbarui", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ScanResultActivity.this, "Gagal update Qty", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                Toast.makeText(ScanResultActivity.this, "Gagal koneksi ke server", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Fungsi untuk update Rak ke server
    private void updateRakToServer(String cNoOp, String newRak) {
        ApiService service = ApiClient.getClient().create(ApiService.class);
        service.updateRak(cNoOp, newRak).enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    detail.cRak = newRak;
                    showDetail(null);
                    Toast.makeText(ScanResultActivity.this, "Rak berhasil diperbarui", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ScanResultActivity.this, "Gagal update Rak", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                Toast.makeText(ScanResultActivity.this, "Gagal koneksi ke server", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
