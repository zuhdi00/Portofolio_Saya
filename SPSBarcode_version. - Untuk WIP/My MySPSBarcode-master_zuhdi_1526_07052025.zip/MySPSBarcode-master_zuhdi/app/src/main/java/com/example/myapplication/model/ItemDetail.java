package com.example.myapplication.model;


public class ItemDetail {
    public String cNoSTB;
    public String cNamabrg;
    public String cNoMC;
    public String cNoOp;
    public String cNama;
    public double nPanjang;
    public double nLebar;
    public double nTinggi;
    public String cWarna;
    public String cSub1;
    public String cSub2;
    public String cSub3;
    public String cSub4;
    public String cSub5;
    public double nQty;
    public double nQtyKg;
    public String dTglSerah;
    public String cRak;
}
