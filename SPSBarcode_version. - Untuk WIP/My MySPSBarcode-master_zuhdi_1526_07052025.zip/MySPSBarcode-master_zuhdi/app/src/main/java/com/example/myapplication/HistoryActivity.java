package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.sql.Connection;
import android.widget.Toast;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import android.widget.Button;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;


import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private ListView listHistory;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        listHistory = findViewById(R.id.listHistory);

        Button btnInsert = findViewById(R.id.btnInsert);

        btnInsert.setOnClickListener(view -> {

            Toast.makeText(this, "Fitur insert dinonaktifkan", Toast.LENGTH_SHORT).show();

            /*
            Connection conn = SQLConnectionHelper.connect();
            if (conn != null) {
                try {
                    String sql = "INSERT INTO produk (nama_produk) VALUES ('Produk Uji Coba')";
                    Statement stmt = conn.createStatement();
                    int rows = stmt.executeUpdate(sql);

                    if (rows > 0) {
                        Log.d("SQL_INSERT", "Berhasil insert data");
                        Toast.makeText(this, "Insert berhasil!", Toast.LENGTH_SHORT).show();
                    }

                    conn.close();
                } catch (SQLException e) {
                    Log.e("SQL_ERROR", "Insert error: " + e.getMessage());
                    Toast.makeText(this, "Insert gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Koneksi gagal!", Toast.LENGTH_SHORT).show();
            }
            */
            refreshScanData();
        });

        refreshScanData();

        // Ambil data dari SharedPreferences
        ScanHistoryManager historyManager = new ScanHistoryManager(this);
        List<String> scanList = historyManager.getHistory();

        // Tampilkan di ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                scanList
        );


        listHistory.setAdapter(adapter);
        Log.d("HistoryData", "Data: " + scanList.toString());



        /*
        // 🔌 Koneksi SQL Server
        Connection conn = SQLConnectionHelper.connect();
        if (conn != null) {
            Toast.makeText(this, "Koneksi sukses!", Toast.LENGTH_SHORT).show();

            // ✅ Tambahkan INSERT di sini
            try {
                String sql = "INSERT INTO produk (nama_produk) VALUES ('Produk Uji Coba')";
                Statement stmt = conn.createStatement();
                int rows = stmt.executeUpdate(sql);

                if (rows > 0) {
                    Log.d("SQL_INSERT", "Berhasil insert data");
                }

                conn.close();
            } catch (SQLException e) {
                Log.e("SQL_ERROR", "Insert error: " + e.getMessage());
            }

        } else {
            Toast.makeText(this, "Koneksi gagal!", Toast.LENGTH_SHORT).show();
        }
        */
    }

    private void refreshScanData() {
        // Ambil data dari SharedPreferences
        ScanHistoryManager historyManager = new ScanHistoryManager(this);
        List<String> scanList = historyManager.getHistory();

        // Tampilkan di ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                scanList
        );
        listHistory.setAdapter(adapter);
        Log.d("HistoryData", "Data Scan: " + scanList.toString());

        // Tambah listener klik item
        listHistory.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = scanList.get(position);
            StringBuilder formatted = new StringBuilder();

            try {
                if (selectedItem.trim().startsWith("{")) {
                    // Jika formatnya JSON
                    JSONObject jsonObject = new JSONObject(selectedItem);
                    Iterator<String> keys = jsonObject.keys();

                    while (keys.hasNext()) {
                        String key = keys.next();
                        String value = jsonObject.getString(key);
                        formatted.append(key).append(": ").append(value).append("\n");
                    }
                } else {
                    // Format: key1:value1,key2:value2
                    String[] parts = selectedItem.split(",");
                    for (String part : parts) {
                        String[] kv = part.split(":");
                        if (kv.length == 2) {
                            formatted.append(kv[0].trim()).append(": ").append(kv[1].trim()).append("\n");
                        } else {
                            formatted.append(part).append("\n"); // fallback
                        }
                    }
                }
            } catch (JSONException e) {
                formatted.append(selectedItem); // fallback jika gagal parse
            }

            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Detail Hasil Scan")
                    .setMessage(formatted.toString())
                    .setPositiveButton("OK", null)
                    .show();
        });

    }


}
