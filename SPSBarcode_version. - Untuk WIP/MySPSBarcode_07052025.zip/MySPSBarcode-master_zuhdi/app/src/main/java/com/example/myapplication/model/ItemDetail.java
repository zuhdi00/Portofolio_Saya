package com.example.myapplication.model;


public class ItemDetail {
    public String cNoOp;
    public String dTgl;
    public String cNoSc;
    public String dTglkirim;
    public double nQty;  // gunakan double untuk presisi lebih tinggi
    public double nQty_corr; // gunakan double untuk presisi lebih tinggi
    public double nRm; // gunakan double untuk presisi lebih tinggi
    public String cMengetahui;
    public String cNoMc;
    public String cnm_c;
    public String cnm_brg;
    public String cLayer;
    public String cTipe;
    public double nTot_netto; // gunakan double untuk presisi lebih tinggi
    public double nPanjang; // gunakan double untuk presisi lebih tinggi
    public double nLebar; // gunakan double untuk presisi lebih tinggi
    public double nTinggi; // gunakan double untuk presisi lebih tinggi
    public String cWarna;
}
