package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.api.ApiClient;
import com.example.myapplication.api.ApiService;
import com.example.myapplication.model.ItemDetail;
import com.example.myapplication.model.ServerResponse;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanResultActivity extends AppCompatActivity {
    private TextView resultTextView;
    private Button btnEdit;
    private ItemDetail detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_result);

        resultTextView = findViewById(R.id.resultTextView);
        btnEdit = findViewById(R.id.btnEdit);

        String scannedData = getIntent().getStringExtra("scanned_data");
        String detailJson = getIntent().getStringExtra("detail");

        if (detailJson != null) {
            Gson gson = new Gson();
            detail = gson.fromJson(detailJson, ItemDetail.class);
        }

        showDetail(scannedData);

        btnEdit.setOnClickListener(v -> showEditOptionsDialog());
    }

    private void showDetail(String scannedData) {
        StringBuilder resultBuilder = new StringBuilder();

        if (scannedData != null) {
            resultBuilder.append("Hasil Scan: ").append(scannedData).append("\n\n");
        }

        if (detail != null) {
            resultBuilder.append("Detail Barang:\n");
            resultBuilder.append("No OP         : ").append(detail.cNoOp).append("\n");
            resultBuilder.append("Tgl           : ").append(detail.dTgl).append("\n");
            resultBuilder.append("No SC         : ").append(detail.cNoSc).append("\n");
            resultBuilder.append("Tgl Kirim     : ").append(detail.dTglkirim).append("\n");
            resultBuilder.append("Qty           : ").append(detail.nQty).append("\n");
            resultBuilder.append("Qty Corr      : ").append(detail.nQty_corr).append("\n");
            resultBuilder.append("RM            : ").append(detail.nRm).append("\n");
            resultBuilder.append("Mengetahui    : ").append(detail.cMengetahui).append("\n");
            resultBuilder.append("No MC         : ").append(detail.cNoMc).append("\n");
            resultBuilder.append("Customer      : ").append(detail.cnm_c).append("\n");
            resultBuilder.append("Nama Barang   : ").append(detail.cnm_brg).append("\n");
            resultBuilder.append("Layer         : ").append(detail.cLayer).append("\n");
            resultBuilder.append("Tipe          : ").append(detail.cTipe).append("\n");
            resultBuilder.append("Total Netto   : ").append(detail.nTot_netto).append("\n");
            resultBuilder.append("Panjang       : ").append(detail.nPanjang).append("\n");
            resultBuilder.append("Lebar         : ").append(detail.nLebar).append("\n");
            resultBuilder.append("Tinggi        : ").append(detail.nTinggi).append("\n");
            resultBuilder.append("Warna         : ").append(detail.cWarna).append("\n");
        } else {
            resultBuilder.append("Tidak ada detail barang ditemukan.");
        }

        resultTextView.setText(resultBuilder.toString());
    }

    private void showEditOptionsDialog() {
        String[] options = {"Edit Qty", "Edit Lainnya"};
        new AlertDialog.Builder(this)
                .setTitle("Pilih Atribut yang Diedit")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        showEditQtyDialog();
                    } else {
                        Toast.makeText(this, "Edit lainnya belum diimplementasikan.", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showEditQtyDialog() {
        final View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_qty, null);
        final TextView qtyInput = dialogView.findViewById(R.id.editQtyInput);
        qtyInput.setText(String.valueOf(detail.nQty));

        new AlertDialog.Builder(this)
                .setTitle("Edit Qty")
                .setView(dialogView)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    try {
                        double newQty = Double.parseDouble(qtyInput.getText().toString());
                        updateQtyToServer(detail.cNoOp, newQty);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Qty tidak valid", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void updateQtyToServer(String cNoOp, double newQty) {
        ApiService service = ApiClient.getClient().create(ApiService.class);
        service.updateQty(cNoOp, newQty).enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                    detail.nQty = newQty;
                    showDetail(null);
                    Toast.makeText(ScanResultActivity.this, "Qty berhasil diperbarui", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ScanResultActivity.this, "Gagal update Qty", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                Toast.makeText(ScanResultActivity.this, "Gagal koneksi ke server", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
